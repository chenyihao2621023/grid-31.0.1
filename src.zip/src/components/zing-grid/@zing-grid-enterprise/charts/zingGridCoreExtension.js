/**
 * Internal Use Only: Used to ensure this file is treated as a module until we can use moduleDetection flag in Ts v4.7
 */
export const __FORCE_MODULE_DETECTION_AG_GRID_CORE_EXT = 0;
//# sourceMappingURL=zingGridCoreExtension.js.map