export { EnterpriseCoreModule } from "./zingGridEnterpriseModule";
export { GridLicenseManager as LicenseManager } from "./license/gridLicenseManager";
//# sourceMappingURL=main.js.map