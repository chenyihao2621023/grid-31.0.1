export { ClipboardModule } from "./clipboardModule";
//# sourceMappingURL=main.js.map