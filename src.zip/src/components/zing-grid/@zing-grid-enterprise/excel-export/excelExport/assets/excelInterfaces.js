export {};
//# sourceMappingURL=excelInterfaces.js.map