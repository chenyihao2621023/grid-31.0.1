var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Component, RefSelector, PositionableFeature } from "@/components/zing-grid/@zing-grid-community/core/main.js";
export class PrimaryColsPanel extends Component {
    constructor() {
        super(PrimaryColsPanel.TEMPLATE);
    }
    // we allow dragging in the toolPanel, but not when this component appears in the column menu
    init(allowDragging, params, eventType) {
        this.allowDragging = allowDragging;
        this.params = params;
        this.eventType = eventType;
        this.primaryColsHeaderPanel.init(this.params);
        const hideFilter = this.params.suppressColumnFilter;
        const hideSelect = this.params.suppressColumnSelectAll;
        const hideExpand = this.params.suppressColumnExpandAll;
        if (hideExpand && hideFilter && hideSelect) {
            this.primaryColsHeaderPanel.setDisplayed(false);
        }
        this.addManagedListener(this.primaryColsListPanel, 'groupExpanded', this.onGroupExpanded.bind(this));
        this.addManagedListener(this.primaryColsListPanel, 'selectionChanged', this.onSelectionChange.bind(this));
        this.primaryColsListPanel.init(this.params, this.allowDragging, this.eventType);
        this.addManagedListener(this.primaryColsHeaderPanel, 'expandAll', this.onExpandAll.bind(this));
        this.addManagedListener(this.primaryColsHeaderPanel, 'collapseAll', this.onCollapseAll.bind(this));
        this.addManagedListener(this.primaryColsHeaderPanel, 'selectAll', this.onSelectAll.bind(this));
        this.addManagedListener(this.primaryColsHeaderPanel, 'unselectAll', this.onUnselectAll.bind(this));
        this.addManagedListener(this.primaryColsHeaderPanel, 'filterChanged', this.onFilterChanged.bind(this));
        this.positionableFeature = new PositionableFeature(this.getGui(), { minHeight: 100 });
        this.createManagedBean(this.positionableFeature);
    }
    toggleResizable(resizable) {
        this.positionableFeature.setResizable(resizable ? { bottom: true } : false);
    }
    onExpandAll() {
        this.primaryColsListPanel.doSetExpandedAll(true);
    }
    onCollapseAll() {
        this.primaryColsListPanel.doSetExpandedAll(false);
    }
    expandGroups(groupIds) {
        this.primaryColsListPanel.setGroupsExpanded(true, groupIds);
    }
    collapseGroups(groupIds) {
        this.primaryColsListPanel.setGroupsExpanded(false, groupIds);
    }
    setColumnLayout(colDefs) {
        this.primaryColsListPanel.setColumnLayout(colDefs);
    }
    onFilterChanged(event) {
        this.primaryColsListPanel.setFilterText(event.filterText);
    }
    syncLayoutWithGrid() {
        this.primaryColsListPanel.onColumnsChanged();
    }
    onSelectAll() {
        this.primaryColsListPanel.doSetSelectedAll(true);
    }
    onUnselectAll() {
        this.primaryColsListPanel.doSetSelectedAll(false);
    }
    onGroupExpanded(event) {
        this.primaryColsHeaderPanel.setExpandState(event.state);
        this.params.onStateUpdated();
    }
    onSelectionChange(event) {
        this.primaryColsHeaderPanel.setSelectionState(event.state);
    }
    getExpandedGroups() {
        return this.primaryColsListPanel.getExpandedGroups();
    }
}
PrimaryColsPanel.TEMPLATE = `<div class="zing-column-select">
            <zing-primary-cols-header ref="primaryColsHeaderPanel"></zing-primary-cols-header>
            <zing-primary-cols-list ref="primaryColsListPanel"></zing-primary-cols-list>
        </div>`;
__decorate([
    RefSelector('primaryColsHeaderPanel')
], PrimaryColsPanel.prototype, "primaryColsHeaderPanel", void 0);
__decorate([
    RefSelector('primaryColsListPanel')
], PrimaryColsPanel.prototype, "primaryColsListPanel", void 0);
//# sourceMappingURL=primaryColsPanel.js.map