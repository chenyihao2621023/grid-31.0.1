export const zingGridAllModule = {};
//# sourceMappingURL=zingGridAllModule.js.map