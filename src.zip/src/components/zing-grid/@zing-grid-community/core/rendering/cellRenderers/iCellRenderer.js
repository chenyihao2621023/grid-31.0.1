export {};
//# sourceMappingURL=iCellRenderer.js.map