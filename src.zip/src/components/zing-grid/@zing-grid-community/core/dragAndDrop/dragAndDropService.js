var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var DragAndDropService_1;
import { BeanStub } from "../context/beanStub";
import { PostConstruct, Bean, Autowired, PreDestroy } from "../context/context";
import { escapeString } from "../utils/string";
import { createIcon } from "../utils/icon";
import { flatten, removeFromArray } from "../utils/array";
import { getBodyHeight, getBodyWidth } from "../utils/browser";
import { loadTemplate, clearElement, getElementRectWithOffset } from "../utils/dom";
import { isFunction } from "../utils/function";
import { HorizontalDirection, VerticalDirection } from "../constants/direction";
export var DragSourceType;
(function (DragSourceType) {
    DragSourceType[DragSourceType["ToolPanel"] = 0] = "ToolPanel";
    DragSourceType[DragSourceType["HeaderCell"] = 1] = "HeaderCell";
    DragSourceType[DragSourceType["RowDrag"] = 2] = "RowDrag";
    DragSourceType[DragSourceType["ChartPanel"] = 3] = "ChartPanel";
    DragSourceType[DragSourceType["AdvancedFilterBuilder"] = 4] = "AdvancedFilterBuilder";
})(DragSourceType || (DragSourceType = {}));
let DragAndDropService = DragAndDropService_1 = class DragAndDropService extends BeanStub {
    constructor() {
        super(...arguments);
        this.dragSourceAndParamsList = [];
        this.dropTargets = [];
    }
    init() {
        this.ePinnedIcon = createIcon('columnMovePin', this.gridOptionsService, null);
        this.eHideIcon = createIcon('columnMoveHide', this.gridOptionsService, null);
        this.eMoveIcon = createIcon('columnMoveMove', this.gridOptionsService, null);
        this.eLeftIcon = createIcon('columnMoveLeft', this.gridOptionsService, null);
        this.eRightIcon = createIcon('columnMoveRight', this.gridOptionsService, null);
        this.eGroupIcon = createIcon('columnMoveGroup', this.gridOptionsService, null);
        this.eAggregateIcon = createIcon('columnMoveValue', this.gridOptionsService, null);
        this.ePivotIcon = createIcon('columnMovePivot', this.gridOptionsService, null);
        this.eDropNotAllowedIcon = createIcon('dropNotAllowed', this.gridOptionsService, null);
    }
    addDragSource(dragSource, allowTouch = false) {
        const params = {
            eElement: dragSource.eElement,
            dragStartPixels: dragSource.dragStartPixels,
            onDragStart: this.onDragStart.bind(this, dragSource),
            onDragStop: this.onDragStop.bind(this),
            onDragging: this.onDragging.bind(this),
            includeTouch: allowTouch
        };
        this.dragSourceAndParamsList.push({ params: params, dragSource: dragSource });
        this.dragService.addDragSource(params);
    }
    removeDragSource(dragSource) {
        const sourceAndParams = this.dragSourceAndParamsList.find(item => item.dragSource === dragSource);
        if (sourceAndParams) {
            this.dragService.removeDragSource(sourceAndParams.params);
            removeFromArray(this.dragSourceAndParamsList, sourceAndParams);
        }
    }
    clearDragSourceParamsList() {
        this.dragSourceAndParamsList.forEach(sourceAndParams => this.dragService.removeDragSource(sourceAndParams.params));
        this.dragSourceAndParamsList.length = 0;
        this.dropTargets.length = 0;
    }
    nudge() {
        if (this.dragging) {
            this.onDragging(this.eventLastTime, true);
        }
    }
    onDragStart(dragSource, mouseEvent) {
        this.dragging = true;
        this.dragSource = dragSource;
        this.eventLastTime = mouseEvent;
        this.dragItem = this.dragSource.getDragItem();
        this.lastDropTarget = this.dragSource.dragSourceDropTarget;
        if (this.dragSource.onDragStarted) {
            this.dragSource.onDragStarted();
        }
        this.createGhost();
    }
    onDragStop(mouseEvent) {
        this.eventLastTime = null;
        this.dragging = false;
        if (this.dragSource.onDragStopped) {
            this.dragSource.onDragStopped();
        }
        if (this.lastDropTarget && this.lastDropTarget.onDragStop) {
            const draggingEvent = this.createDropTargetEvent(this.lastDropTarget, mouseEvent, null, null, false);
            this.lastDropTarget.onDragStop(draggingEvent);
        }
        this.lastDropTarget = null;
        this.dragItem = null;
        this.removeGhost();
    }
    onDragging(mouseEvent, fromNudge) {
        var _a, _b, _c, _d;
        const hDirection = this.getHorizontalDirection(mouseEvent);
        const vDirection = this.getVerticalDirection(mouseEvent);
        this.eventLastTime = mouseEvent;
        this.positionGhost(mouseEvent);
        // check if mouseEvent intersects with any of the drop targets
        const validDropTargets = this.dropTargets.filter(target => this.isMouseOnDropTarget(mouseEvent, target));
        const dropTarget = this.findCurrentDropTarget(mouseEvent, validDropTargets);
        if (dropTarget !== this.lastDropTarget) {
            this.leaveLastTargetIfExists(mouseEvent, hDirection, vDirection, fromNudge);
            if (this.lastDropTarget !== null && dropTarget === null) {
                (_b = (_a = this.dragSource).onGridExit) === null || _b === void 0 ? void 0 : _b.call(_a, this.dragItem);
            }
            if (this.lastDropTarget === null && dropTarget !== null) {
                (_d = (_c = this.dragSource).onGridEnter) === null || _d === void 0 ? void 0 : _d.call(_c, this.dragItem);
            }
            this.enterDragTargetIfExists(dropTarget, mouseEvent, hDirection, vDirection, fromNudge);
            this.lastDropTarget = dropTarget;
        }
        else if (dropTarget && dropTarget.onDragging) {
            const draggingEvent = this.createDropTargetEvent(dropTarget, mouseEvent, hDirection, vDirection, fromNudge);
            dropTarget.onDragging(draggingEvent);
        }
    }
    getAllContainersFromDropTarget(dropTarget) {
        const secondaryContainers = dropTarget.getSecondaryContainers ? dropTarget.getSecondaryContainers() : null;
        const containers = [[dropTarget.getContainer()]];
        return secondaryContainers ? containers.concat(secondaryContainers) : containers;
    }
    allContainersIntersect(mouseEvent, containers) {
        for (const container of containers) {
            const rect = container.getBoundingClientRect();
            // if element is not visible, then width and height are zero
            if (rect.width === 0 || rect.height === 0) {
                return false;
            }
            const horizontalFit = mouseEvent.clientX >= rect.left && mouseEvent.clientX < rect.right;
            const verticalFit = mouseEvent.clientY >= rect.top && mouseEvent.clientY < rect.bottom;
            if (!horizontalFit || !verticalFit) {
                return false;
            }
        }
        return true;
    }
    // checks if the mouse is on the drop target. it checks eContainer and eSecondaryContainers
    isMouseOnDropTarget(mouseEvent, dropTarget) {
        const allContainersFromDropTarget = this.getAllContainersFromDropTarget(dropTarget);
        let mouseOverTarget = false;
        for (const currentContainers of allContainersFromDropTarget) {
            if (this.allContainersIntersect(mouseEvent, currentContainers)) {
                mouseOverTarget = true;
                break;
            }
        }
        if (dropTarget.targetContainsSource && !dropTarget.getContainer().contains(this.dragSource.eElement)) {
            return false;
        }
        return mouseOverTarget && dropTarget.isInterestedIn(this.dragSource.type, this.dragSource.eElement);
    }
    findCurrentDropTarget(mouseEvent, validDropTargets) {
        const len = validDropTargets.length;
        if (len === 0) {
            return null;
        }
        if (len === 1) {
            return validDropTargets[0];
        }
        const rootNode = this.gridOptionsService.getRootNode();
        // elementsFromPoint return a list of elements under
        // the mouseEvent sorted from topMost to bottomMost
        const elementStack = rootNode.elementsFromPoint(mouseEvent.clientX, mouseEvent.clientY);
        // loop over the sorted elementStack to find which dropTarget comes first
        for (const el of elementStack) {
            for (const dropTarget of validDropTargets) {
                const containers = flatten(this.getAllContainersFromDropTarget(dropTarget));
                if (containers.indexOf(el) !== -1) {
                    return dropTarget;
                }
            }
        }
        // we should never hit this point of the code because only
        // valid dropTargets should be provided to this method.
        return null;
    }
    enterDragTargetIfExists(dropTarget, mouseEvent, hDirection, vDirection, fromNudge) {
        if (!dropTarget) {
            return;
        }
        if (dropTarget.onDragEnter) {
            const dragEnterEvent = this.createDropTargetEvent(dropTarget, mouseEvent, hDirection, vDirection, fromNudge);
            dropTarget.onDragEnter(dragEnterEvent);
        }
        this.setGhostIcon(dropTarget.getIconName ? dropTarget.getIconName() : null);
    }
    leaveLastTargetIfExists(mouseEvent, hDirection, vDirection, fromNudge) {
        if (!this.lastDropTarget) {
            return;
        }
        if (this.lastDropTarget.onDragLeave) {
            const dragLeaveEvent = this.createDropTargetEvent(this.lastDropTarget, mouseEvent, hDirection, vDirection, fromNudge);
            this.lastDropTarget.onDragLeave(dragLeaveEvent);
        }
        this.setGhostIcon(null);
    }
    addDropTarget(dropTarget) {
        this.dropTargets.push(dropTarget);
    }
    removeDropTarget(dropTarget) {
        this.dropTargets = this.dropTargets.filter(target => target.getContainer() !== dropTarget.getContainer());
    }
    hasExternalDropZones() {
        return this.dropTargets.some(zones => zones.external);
    }
    findExternalZone(params) {
        const externalTargets = this.dropTargets.filter(target => target.external);
        return externalTargets.find(zone => zone.getContainer() === params.getContainer()) || null;
    }
    getHorizontalDirection(event) {
        const clientX = this.eventLastTime && this.eventLastTime.clientX;
        const eClientX = event.clientX;
        if (clientX === eClientX) {
            return null;
        }
        return clientX > eClientX ? HorizontalDirection.Left : HorizontalDirection.Right;
    }
    getVerticalDirection(event) {
        const clientY = this.eventLastTime && this.eventLastTime.clientY;
        const eClientY = event.clientY;
        if (clientY === eClientY) {
            return null;
        }
        return clientY > eClientY ? VerticalDirection.Up : VerticalDirection.Down;
    }
    createDropTargetEvent(dropTarget, event, hDirection, vDirection, fromNudge) {
        // localise x and y to the target
        const dropZoneTarget = dropTarget.getContainer();
        const rect = dropZoneTarget.getBoundingClientRect();
        const { gridApi: api, columnApi, dragItem, dragSource } = this;
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        return { event, x, y, vDirection, hDirection, dragSource, fromNudge, dragItem: dragItem, api, columnApi, dropZoneTarget };
    }
    positionGhost(event) {
        const ghost = this.eGhost;
        if (!ghost) {
            return;
        }
        const ghostRect = ghost.getBoundingClientRect();
        const ghostHeight = ghostRect.height;
        const browserWidth = getBodyWidth() - 2; // 2px for 1px borderLeft and 1px borderRight
        const browserHeight = getBodyHeight() - 2; // 2px for 1px borderTop and 1px borderBottom
        const offsetParentSize = getElementRectWithOffset(ghost.offsetParent);
        const { clientY, clientX } = event;
        let top = (clientY - offsetParentSize.top) - (ghostHeight / 2);
        let left = (clientX - offsetParentSize.left) - 10;
        const eDocument = this.gridOptionsService.getDocument();
        const win = (eDocument.defaultView || window);
        const windowScrollY = win.pageYOffset || eDocument.documentElement.scrollTop;
        const windowScrollX = win.pageXOffset || eDocument.documentElement.scrollLeft;
        // check ghost is not positioned outside of the browser
        if (browserWidth > 0 && ((left + ghost.clientWidth) > (browserWidth + windowScrollX))) {
            left = browserWidth + windowScrollX - ghost.clientWidth;
        }
        if (left < 0) {
            left = 0;
        }
        if (browserHeight > 0 && ((top + ghost.clientHeight) > (browserHeight + windowScrollY))) {
            top = browserHeight + windowScrollY - ghost.clientHeight;
        }
        if (top < 0) {
            top = 0;
        }
        ghost.style.left = `${left}px`;
        ghost.style.top = `${top}px`;
    }
    removeGhost() {
        if (this.eGhost && this.eGhostParent) {
            this.eGhostParent.removeChild(this.eGhost);
        }
        this.eGhost = null;
    }
    createGhost() {
        this.eGhost = loadTemplate(DragAndDropService_1.GHOST_TEMPLATE);
        this.mouseEventService.stampTopLevelGridCompWithGridInstance(this.eGhost);
        const { theme } = this.environment.getTheme();
        if (theme) {
            this.eGhost.classList.add(theme);
        }
        this.eGhostIcon = this.eGhost.querySelector('.zing-dnd-ghost-icon');
        this.setGhostIcon(null);
        const eText = this.eGhost.querySelector('.zing-dnd-ghost-label');
        let dragItemName = this.dragSource.dragItemName;
        if (isFunction(dragItemName)) {
            dragItemName = dragItemName();
        }
        eText.innerHTML = escapeString(dragItemName) || '';
        this.eGhost.style.height = '25px';
        this.eGhost.style.top = '20px';
        this.eGhost.style.left = '20px';
        const eDocument = this.gridOptionsService.getDocument();
        let rootNode = null;
        let targetEl = null;
        try {
            rootNode = eDocument.fullscreenElement;
        }
        catch (e) {
            // some environments like SalesForce will throw errors
            // simply by trying to read the fullscreenElement property
        }
        finally {
            if (!rootNode) {
                rootNode = this.gridOptionsService.getRootNode();
            }
            const body = rootNode.querySelector('body');
            if (body) {
                targetEl = body;
            }
            else if (rootNode instanceof ShadowRoot) {
                targetEl = rootNode;
            }
            else if (rootNode instanceof Document) {
                targetEl = rootNode === null || rootNode === void 0 ? void 0 : rootNode.documentElement;
            }
            else {
                targetEl = rootNode;
            }
        }
        this.eGhostParent = targetEl;
        if (!this.eGhostParent) {
            console.warn('ZING Grid: could not find document body, it is needed for dragging columns');
        }
        else {
            this.eGhostParent.appendChild(this.eGhost);
        }
    }
    setGhostIcon(iconName, shake = false) {
        clearElement(this.eGhostIcon);
        let eIcon = null;
        if (!iconName) {
            iconName = this.dragSource.getDefaultIconName ? this.dragSource.getDefaultIconName() : DragAndDropService_1.ICON_NOT_ALLOWED;
        }
        switch (iconName) {
            case DragAndDropService_1.ICON_PINNED:
                eIcon = this.ePinnedIcon;
                break;
            case DragAndDropService_1.ICON_MOVE:
                eIcon = this.eMoveIcon;
                break;
            case DragAndDropService_1.ICON_LEFT:
                eIcon = this.eLeftIcon;
                break;
            case DragAndDropService_1.ICON_RIGHT:
                eIcon = this.eRightIcon;
                break;
            case DragAndDropService_1.ICON_GROUP:
                eIcon = this.eGroupIcon;
                break;
            case DragAndDropService_1.ICON_AGGREGATE:
                eIcon = this.eAggregateIcon;
                break;
            case DragAndDropService_1.ICON_PIVOT:
                eIcon = this.ePivotIcon;
                break;
            case DragAndDropService_1.ICON_NOT_ALLOWED:
                eIcon = this.eDropNotAllowedIcon;
                break;
            case DragAndDropService_1.ICON_HIDE:
                eIcon = this.eHideIcon;
                break;
        }
        this.eGhostIcon.classList.toggle('zing-shake-left-to-right', shake);
        if (eIcon === this.eHideIcon && this.gridOptionsService.get('suppressDragLeaveHidesColumns')) {
            return;
        }
        if (eIcon) {
            this.eGhostIcon.appendChild(eIcon);
        }
    }
};
DragAndDropService.ICON_PINNED = 'pinned';
DragAndDropService.ICON_MOVE = 'move';
DragAndDropService.ICON_LEFT = 'left';
DragAndDropService.ICON_RIGHT = 'right';
DragAndDropService.ICON_GROUP = 'group';
DragAndDropService.ICON_AGGREGATE = 'aggregate';
DragAndDropService.ICON_PIVOT = 'pivot';
DragAndDropService.ICON_NOT_ALLOWED = 'notAllowed';
DragAndDropService.ICON_HIDE = 'hide';
DragAndDropService.GHOST_TEMPLATE = `<div class="zing-dnd-ghost zing-unselectable">
            <span class="zing-dnd-ghost-icon zing-shake-left-to-right"></span>
            <div class="zing-dnd-ghost-label"></div>
        </div>`;
__decorate([
    Autowired('dragService')
], DragAndDropService.prototype, "dragService", void 0);
__decorate([
    Autowired('mouseEventService')
], DragAndDropService.prototype, "mouseEventService", void 0);
__decorate([
    Autowired('columnApi')
], DragAndDropService.prototype, "columnApi", void 0);
__decorate([
    Autowired('gridApi')
], DragAndDropService.prototype, "gridApi", void 0);
__decorate([
    PostConstruct
], DragAndDropService.prototype, "init", null);
__decorate([
    PreDestroy
], DragAndDropService.prototype, "clearDragSourceParamsList", null);
DragAndDropService = DragAndDropService_1 = __decorate([
    Bean('dragAndDropService')
], DragAndDropService);
export { DragAndDropService };
//# sourceMappingURL=dragAndDropService.js.map