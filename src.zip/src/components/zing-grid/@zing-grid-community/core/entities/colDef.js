export {};
//# sourceMappingURL=colDef.js.map