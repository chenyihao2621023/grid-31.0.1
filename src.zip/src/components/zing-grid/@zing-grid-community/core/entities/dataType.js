export {};
//# sourceMappingURL=dataType.js.map