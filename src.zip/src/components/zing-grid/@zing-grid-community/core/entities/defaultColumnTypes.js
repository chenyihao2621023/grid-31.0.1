export const DefaultColumnTypes = {
    numericColumn: {
        headerClass: 'zing-right-aligned-header',
        cellClass: 'zing-right-aligned-cell'
    },
    rightAligned: {
        headerClass: 'zing-right-aligned-header',
        cellClass: 'zing-right-aligned-cell'
    }
};
//# sourceMappingURL=defaultColumnTypes.js.map