export {};
//# sourceMappingURL=iLogger.js.map