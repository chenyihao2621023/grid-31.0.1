export {};
//# sourceMappingURL=floatingFilter.js.map