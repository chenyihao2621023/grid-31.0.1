export var RowHighlightPosition;
(function (RowHighlightPosition) {
    RowHighlightPosition[RowHighlightPosition["Above"] = 0] = "Above";
    RowHighlightPosition[RowHighlightPosition["Below"] = 1] = "Below";
})(RowHighlightPosition || (RowHighlightPosition = {}));
//# sourceMappingURL=iRowNode.js.map