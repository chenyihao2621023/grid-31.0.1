export {};
//# sourceMappingURL=iClipboardService.js.map