export {};
//# sourceMappingURL=iHeaderColumn.js.map