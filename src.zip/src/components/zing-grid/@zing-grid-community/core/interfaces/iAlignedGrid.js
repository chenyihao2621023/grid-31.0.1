export {};
//# sourceMappingURL=iAlignedGrid.js.map