export {};
//# sourceMappingURL=iSelectionService.js.map