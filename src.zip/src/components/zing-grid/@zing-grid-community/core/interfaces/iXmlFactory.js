export {};
//# sourceMappingURL=iXmlFactory.js.map