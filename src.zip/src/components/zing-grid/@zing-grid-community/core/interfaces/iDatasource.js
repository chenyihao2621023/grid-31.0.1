export {};
//# sourceMappingURL=iDatasource.js.map