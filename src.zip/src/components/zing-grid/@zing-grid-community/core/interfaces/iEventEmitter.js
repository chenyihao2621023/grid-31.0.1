export {};
//# sourceMappingURL=iEventEmitter.js.map