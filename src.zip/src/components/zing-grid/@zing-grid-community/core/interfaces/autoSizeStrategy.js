export {};
//# sourceMappingURL=autoSizeStrategy.js.map