export {};
//# sourceMappingURL=iMenuFactory.js.map