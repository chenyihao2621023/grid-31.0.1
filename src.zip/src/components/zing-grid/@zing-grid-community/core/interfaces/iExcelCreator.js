// Excel Export
export var ExcelFactoryMode;
(function (ExcelFactoryMode) {
    ExcelFactoryMode[ExcelFactoryMode["SINGLE_SHEET"] = 0] = "SINGLE_SHEET";
    ExcelFactoryMode[ExcelFactoryMode["MULTI_SHEET"] = 1] = "MULTI_SHEET";
})(ExcelFactoryMode || (ExcelFactoryMode = {}));
//# sourceMappingURL=iExcelCreator.js.map