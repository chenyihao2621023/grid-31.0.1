export {};
//# sourceMappingURL=IChartService.js.map