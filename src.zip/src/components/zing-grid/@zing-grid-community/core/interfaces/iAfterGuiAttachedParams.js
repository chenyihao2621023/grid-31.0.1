export {};
//# sourceMappingURL=iAfterGuiAttachedParams.js.map