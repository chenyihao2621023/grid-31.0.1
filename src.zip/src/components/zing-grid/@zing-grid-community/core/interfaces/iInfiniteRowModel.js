export {};
//# sourceMappingURL=iInfiniteRowModel.js.map