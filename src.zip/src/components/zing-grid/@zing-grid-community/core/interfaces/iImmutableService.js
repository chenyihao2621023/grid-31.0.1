export {};
//# sourceMappingURL=iImmutableService.js.map