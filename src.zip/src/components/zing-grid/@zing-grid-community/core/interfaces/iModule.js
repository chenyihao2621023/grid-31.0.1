export {};
//# sourceMappingURL=iModule.js.map