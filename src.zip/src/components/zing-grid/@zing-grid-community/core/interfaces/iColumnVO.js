export {};
//# sourceMappingURL=iColumnVO.js.map