export {};
//# sourceMappingURL=iRowModel.js.map