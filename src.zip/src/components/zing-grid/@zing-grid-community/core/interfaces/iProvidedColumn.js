export {};
//# sourceMappingURL=iProvidedColumn.js.map