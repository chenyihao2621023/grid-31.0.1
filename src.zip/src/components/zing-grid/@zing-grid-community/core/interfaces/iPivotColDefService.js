export {};
//# sourceMappingURL=iPivotColDefService.js.map