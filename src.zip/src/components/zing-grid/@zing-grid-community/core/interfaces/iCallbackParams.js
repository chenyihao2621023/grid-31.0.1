export {};
//# sourceMappingURL=iCallbackParams.js.map