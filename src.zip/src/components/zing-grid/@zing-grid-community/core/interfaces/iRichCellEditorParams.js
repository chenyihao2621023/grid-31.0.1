export {};
//# sourceMappingURL=iRichCellEditorParams.js.map