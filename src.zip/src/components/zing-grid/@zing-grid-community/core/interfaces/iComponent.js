export {};
//# sourceMappingURL=iComponent.js.map