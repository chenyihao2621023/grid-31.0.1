export {};
//# sourceMappingURL=masterDetail.js.map