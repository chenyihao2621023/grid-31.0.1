export {};
//# sourceMappingURL=iCommon.js.map