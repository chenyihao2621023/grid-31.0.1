export {};
//# sourceMappingURL=iContextMenuFactory.js.map