export {};
//# sourceMappingURL=iPopupComponent.js.map