export {};
//# sourceMappingURL=IServerSideStore.js.map