export {};
//# sourceMappingURL=iServerSideSelection.js.map