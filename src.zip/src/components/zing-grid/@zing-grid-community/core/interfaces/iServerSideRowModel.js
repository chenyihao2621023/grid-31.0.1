export {};
//# sourceMappingURL=iServerSideRowModel.js.map