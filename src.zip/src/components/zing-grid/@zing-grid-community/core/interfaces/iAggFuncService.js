export {};
//# sourceMappingURL=iAggFuncService.js.map