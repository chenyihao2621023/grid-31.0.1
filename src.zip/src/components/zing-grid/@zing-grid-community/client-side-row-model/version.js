// DO NOT UPDATE MANUALLY: Generated from script during build time
export const VERSION = '31.0.1';
//# sourceMappingURL=version.js.map