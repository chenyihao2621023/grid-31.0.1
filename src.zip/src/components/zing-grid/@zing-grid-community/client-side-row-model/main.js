export { ClientSideRowModelModule } from "./clientSideRowModelModule";
//# sourceMappingURL=main.js.map