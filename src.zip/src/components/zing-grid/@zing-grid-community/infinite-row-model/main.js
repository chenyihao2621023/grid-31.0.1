export { InfiniteRowModelModule } from "./infiniteRowModelModule";
//# sourceMappingURL=main.js.map